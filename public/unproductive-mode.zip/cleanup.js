// Unproductive Mode — Self-contained cleanup script
// Injected when mode is turned OFF
(function () {
  "use strict";

  window.__unproductive_active = false;

  // Run cleanup
  if (window.__unproductive_cleanup) {
    window.__unproductive_cleanup();
    window.__unproductive_cleanup = null;
  }

  // Remove all masks
  var masked = document.querySelectorAll("[data-unproductive-masked]");
  for (var i = 0; i < masked.length; i++) {
    var el = masked[i];
    el.removeAttribute("data-unproductive-masked");
    el.style.removeProperty("filter");
    el.style.removeProperty("pointer-events");
    el.style.removeProperty("user-select");
    el.style.removeProperty("display");
    el.style.removeProperty("overflow");
    var overlay = el.querySelector(".unproductive-overlay");
    if (overlay) overlay.remove();
  }

  // Remove domain overlay
  var bodyOverlay = document.getElementById("unproductive-body-overlay");
  if (bodyOverlay) bodyOverlay.remove();

  console.log("[Unproductive Mode] ❌ Deactivated");
})();
