// Unproductive Mode — Self-contained content injection script
// This file is injected by the background service worker via chrome.scripting.executeScript
(function () {
  "use strict";

  // Prevent double-injection
  if (window.__unproductive_active) return;
  window.__unproductive_active = true;

  console.log(
    "[Unproductive Mode] 🚀 inject.js running on",
    window.location.hostname,
  );

  var MASKED_ATTR = "data-unproductive-masked";
  var OVERLAY_CLASS = "unproductive-overlay";
  var BODY_OVERLAY_ID = "unproductive-body-overlay";
  var SCAN_INTERVAL = 1500;

  // ─── KEYWORDS ───
  var KEYWORDS = [
    "tutorial",
    "how to",
    "guide",
    "documentation",
    "homework",
    "assignment",
    "course",
    "lecture",
    "research",
    "paper",
    "solution",
    "example",
    "docs",
    "stack overflow",
    "github",
    "arxiv",
    "programming",
    "coding",
    "developer",
    "software engineer",
    "devops",
    "algorithm",
    "data structure",
    "leetcode",
    "dsa",
    "competitive programming",
    "system design",
    "api",
    "framework",
    "library",
    "sdk",
    "react",
    "angular",
    "vue",
    "next.js",
    "nuxt",
    "svelte",
    "node.js",
    "python",
    "javascript",
    "typescript",
    "rust",
    "golang",
    "java",
    "c++",
    "swift",
    "kotlin",
    "machine learning",
    "deep learning",
    "neural network",
    "transformer",
    "fine-tuning",
    "training",
    "inference",
    "llm",
    "gpt",
    "claude",
    "openai",
    "anthropic",
    "gemini",
    "copilot",
    "cursor",
    "ai agent",
    "ai coding",
    "code assistant",
    "prompt engineering",
    "docker",
    "kubernetes",
    "aws",
    "azure",
    "gcp",
    "terraform",
    "ci/cd",
    "pipeline",
    "deployment",
    "infrastructure",
    "bootcamp",
    "certification",
    "exam",
    "study",
    "learn",
    "masterclass",
    "workshop",
    "webinar",
    "conference talk",
    "productivity",
    "workflow",
    "automation",
    "debugging",
    "bug fix",
    "code review",
    "pull request",
    "commit",
    "repository",
    "open source",
    "contribution",
    "backend",
    "frontend",
    "full stack",
    "fullstack",
    "sorting",
    "linked list",
    "binary tree",
    "graph theory",
    "hash map",
    "recursion",
    "dynamic programming",
    "greedy",
    "web development",
    "app development",
    "mobile development",
    "computer science",
    "operating system",
    "networking",
    "database",
    "sql",
    "nosql",
    "mongodb",
    "postgresql",
    "mysql",
    "redis",
    "agile",
    "scrum",
    "kanban",
    // CSS / Design / UI keywords
    "tailwind",
    "css",
    "scss",
    "sass",
    "styled-components",
    "shadcn",
    "radix",
    "chakra ui",
    "material ui",
    "bootstrap",
    "responsive design",
    "dark mode",
    "custom styles",
    "grid layout",
    "flexbox",
    "animations",
    "svg animation",
    "framer motion",
    "design system",
    "ui components",
    "loader components",
    "web design",
    "design trends",
    "design engineering",
    "portfolio",
    "project review",
    // More tech terms
    "cli",
    "terminal",
    "command line",
    "bash",
    "shell",
    "webpack",
    "vite",
    "esbuild",
    "bundler",
    "build tool",
    "testing",
    "unit test",
    "integration test",
    "jest",
    "vitest",
    "git",
    "version control",
    "branching",
    "merge",
    "microservices",
    "monorepo",
    "architecture",
    "saas",
    "startup",
    "tech stack",
    "interview",
    "placement",
    "hiring",
    "functions",
    "directives",
    "properties",
    "hover",
    "focus",
    "states",
    "ep-",
    "episode",
  ];

  var PRODUCTIVE_DOMAINS = [
    "github.com",
    "stackoverflow.com",
    "arxiv.org",
    "medium.com",
    "developer.mozilla.org",
    "docs.microsoft.com",
    "takeuforward.org",
    "leetcode.com",
    "geeksforgeeks.org",
    "hackerrank.com",
    "codeforces.com",
    "codechef.com",
    "neetcode.io",
    "interviewbit.com",
    "educative.io",
    "coursera.org",
    "udemy.com",
    "edx.org",
    "khanacademy.org",
    "freecodecamp.org",
    "w3schools.com",
    "codecademy.com",
    "scrimba.com",
    "pluralsight.com",
    "skillshare.com",
    "docs.python.org",
    "devdocs.io",
    "learn.microsoft.com",
    "cloud.google.com",
    "docs.aws.amazon.com",
    "huggingface.co",
    "paperswithcode.com",
    "kaggle.com",
    "openai.com",
    "anthropic.com",
  ];

  var PRODUCTIVE_CHANNELS = [
    "freecodecamp",
    "traversy media",
    "fireship",
    "programming with mosh",
    "clever programmer",
    "code with harry",
    "telusko",
    "neetcode",
    "take u forward",
    "striver",
    "love babbar",
    "apna college",
    "college wallah",
    "piyush garg",
    "harkirat singh",
    "hitesh choudhary",
    "coding ninja",
    "pepcoding",
    "aditya verma",
    "kunal kushwaha",
    "anuj bhaiya",
    "cs dojo",
    "sentdex",
    "corey schafer",
    "web dev simplified",
    "kevin powell",
    "the net ninja",
    "academind",
    "brad traversy",
    "ben awad",
    "jack herrington",
    "theo",
    "primeagen",
    "arpit bhayani",
    "gaurav sen",
    "tushar roy",
    "abdul bari",
    "william fiset",
    "ashish pratap singh",
    "techlead",
    "joma tech",
    "durga software",
    "bro code",
    "brocode",
    "coding with john",
    "matt talks tech",
    "manu arora",
    "tommy chryst",
  ];

  var PRODUCTIVE_TWITTER_HANDLES = [
    "openai",
    "anthropic",
    "googleai",
    "deepmind",
    "huggingface",
    "github",
    "vercel",
    "awscloud",
    "googledevs",
    "microsoftdev",
    "reactjs",
    "vuejs",
    "nodejs",
    "rustlang",
    "golang",
    "karpathy",
    "ylecun",
    "sama",
    "dan_abramov",
    "kentcdodds",
    "wesbos",
    "t3dotgg",
    "fireship_dev",
    "stripe",
    "figma",
    "linear",
    "notion",
    "supabase",
  ];

  // ─── Detection ───
  function isProductive(text) {
    if (!text || text.length < 3) return false;
    var lower = text.toLowerCase();
    for (var i = 0; i < KEYWORDS.length; i++) {
      if (lower.indexOf(KEYWORDS[i]) !== -1) return true;
    }
    for (var j = 0; j < PRODUCTIVE_CHANNELS.length; j++) {
      if (lower.indexOf(PRODUCTIVE_CHANNELS[j]) !== -1) return true;
    }
    return false;
  }

  // ─── CSS injection ───
  if (!document.getElementById("unproductive-injected-styles")) {
    var style = document.createElement("style");
    style.id = "unproductive-injected-styles";
    style.textContent =
      "#" +
      BODY_OVERLAY_ID +
      " {" +
      "  position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;" +
      "  z-index: 2147483647;" +
      "  background: rgba(0,0,0,0.92); backdrop-filter: blur(30px);" +
      "  display: flex; flex-direction: column; align-items: center; justify-content: center;" +
      "  color: #fff; font-family: Inter, system-ui, sans-serif; text-align: center; padding: 40px;" +
      "}" +
      "#" +
      BODY_OVERLAY_ID +
      " h1 { font-size: 3rem; margin-bottom: 12px; }" +
      "#" +
      BODY_OVERLAY_ID +
      " p { font-size: 1.15rem; color: #b2bec3; margin-bottom: 28px; }" +
      "#" +
      BODY_OVERLAY_ID +
      " strong { color: #ff6b6b; }" +
      "#" +
      BODY_OVERLAY_ID +
      " button {" +
      "  padding: 14px 32px; font-size: 1rem; font-weight: 600; border: none; border-radius: 10px;" +
      "  background: linear-gradient(135deg, #e17055, #d63031); color: white; cursor: pointer;" +
      "  box-shadow: 0 4px 20px rgba(214,48,49,0.4); transition: transform .15s, box-shadow .15s;" +
      "}" +
      "#" +
      BODY_OVERLAY_ID +
      " button:hover { transform: translateY(-2px); box-shadow: 0 6px 28px rgba(214,48,49,0.5); }" +
      "#" +
      BODY_OVERLAY_ID +
      " button:disabled { opacity: 0.6; cursor: wait; transform: none; }" +
      "." +
      OVERLAY_CLASS +
      " {" +
      "  position: absolute; inset: 0; z-index: 10000;" +
      "  display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px;" +
      "  background: rgba(0,0,0,0.75); backdrop-filter: blur(6px); border-radius: inherit; pointer-events: auto;" +
      "}" +
      ".unproductive-badge {" +
      "  background: #e17055; color: white; padding: 4px 12px; border-radius: 20px;" +
      "  font-size: 11px; font-weight: 700; font-family: system-ui, sans-serif; letter-spacing: 0.3px;" +
      "}" +
      ".unproductive-show-btn {" +
      "  background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.25);" +
      "  color: white; padding: 5px 14px; border-radius: 6px; cursor: pointer;" +
      "  font-size: 11px; font-family: system-ui, sans-serif; transition: background 0.2s;" +
      "}" +
      ".unproductive-show-btn:hover { background: rgba(255,255,255,0.25); }" +
      ".unproductive-show-btn:disabled { opacity: 0.5; cursor: wait; }";
    (document.head || document.documentElement).appendChild(style);
  }

  // ─── Sarcastic messages ───
  var DOMAIN_ROASTS = [
    "Bro, take a chill pill 💊 Life isn't a hackathon. You're not getting a trophy for burnout.",
    "Touch grass. Seriously. The compiler can wait but your social life can't.",
    "You really opened " +
      window.location.hostname +
      " during chill hours? That's embarrassing.",
    "Plot twist: Netflix won't judge you. This website will. Now close this tab, you absolute nerd.",
    "You're supposed to be UNPRODUCTIVE right now. That's literally the whole point. Read the extension name again.",
    "Error 420: Too much productivity detected. Your brain called — it wants a vacation 🏖️",
    "Nobody on their deathbed ever said 'I wish I spent more time on " +
      window.location.hostname +
      "'",
    "Congrats, you played yourself. Go watch cat videos like a normal person.",
    "The grind never stops? Bro, the grind NEEDS to stop. You look tired.",
    "Your future employer doesn't care that you studied on a Saturday night. Go live a little.",
  ];

  var ELEMENT_ROASTS = [
    "🚫 Nerd Alert",
    "🚫 Sigma Grindset Detected",
    "🚫 Go Touch Grass",
    "🚫 Not Today, Nerd",
    "🚫 Your Brain Needs Rest",
    "🚫 Cringe Productivity",
    "🚫 Log Off, Grindset Boy",
    "🚫 Certified Nerd Moment",
  ];

  function randomFrom(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  // ─── Domain overlay ───
  function showDomainOverlay() {
    if (document.getElementById(BODY_OVERLAY_ID)) return;
    var overlay = document.createElement("div");
    overlay.id = BODY_OVERLAY_ID;
    overlay.innerHTML =
      "<h1>🛑 Whoa There, Nerd!</h1>" +
      '<p style="font-size:1.3rem;max-width:600px;line-height:1.6">' +
      randomFrom(DOMAIN_ROASTS) +
      "</p>" +
      '<p style="font-size:0.85rem;color:#636e72;margin-top:16px">You tried to visit <strong>' +
      window.location.hostname +
      "</strong>... during chill hours? Really? 💀</p>" +
      '<p style="font-size:0.75rem;color:#4a4a4a;margin-top:30px">Turn off Unproductive Mode if you actually need this site.</p>';
    document.documentElement.appendChild(overlay);
  }

  var PEEKING_ATTR = "data-unproductive-peeking";

  // ─── Mask element ───
  function maskElement(el) {
    if (el.getAttribute(MASKED_ATTR)) return;
    if (el.getAttribute(PEEKING_ATTR)) return; // Skip elements being peeked
    el.setAttribute(MASKED_ATTR, "true");
    el.style.setProperty("filter", "blur(8px) grayscale(100%)", "important");
    el.style.setProperty("pointer-events", "none", "important");
    el.style.setProperty("user-select", "none", "important");
    if (window.getComputedStyle(el).position === "static") {
      el.style.setProperty("position", "relative");
    }
    el.style.setProperty("overflow", "hidden");

    var overlay = document.createElement("div");
    overlay.className = OVERLAY_CLASS;
    overlay.innerHTML =
      '<span class="unproductive-badge">' +
      randomFrom(ELEMENT_ROASTS) +
      "</span>" +
      '<button class="unproductive-show-btn">Peek (but why tho?) 👀</button>';
    var btn = overlay.querySelector("button");
    btn.addEventListener("click", function (e) {
      e.stopPropagation();
      e.preventDefault();

      // Immediately reveal the content
      el.removeAttribute(MASKED_ATTR);
      el.setAttribute(PEEKING_ATTR, "true"); // Prevent re-masking
      el.style.removeProperty("filter");
      el.style.removeProperty("pointer-events");
      el.style.removeProperty("user-select");
      el.style.removeProperty("overflow");
      overlay.remove();

      // Re-mask after 10 seconds
      setTimeout(function () {
        el.removeAttribute(PEEKING_ATTR);
        maskElement(el);
      }, 10000);
    });
    el.appendChild(overlay);
  }

  // ─── YouTube scanning ───
  function scanYouTube() {
    // WATCH page
    if (window.location.pathname === "/watch") {
      var titleEl = document.querySelector(
        "h1.ytd-watch-metadata yt-formatted-string, " +
          "#title h1 yt-formatted-string, " +
          "h1.style-scope.ytd-watch-metadata, " +
          "h1.ytd-video-primary-info-renderer yt-formatted-string",
      );
      var videoTitle =
        titleEl && titleEl.textContent
          ? titleEl.textContent.trim()
          : document.title;
      if (isProductive(videoTitle)) {
        var player = document.querySelector(
          "#player, #movie_player, ytd-player",
        );
        if (player) maskElement(player);
        var info = document.querySelector(
          "#above-the-fold, #info-contents, ytd-watch-metadata",
        );
        if (info) maskElement(info);
      }
      // Sidebar recommendations
      var sidebarItems = document.querySelectorAll(
        "ytd-compact-video-renderer",
      );
      for (var s = 0; s < sidebarItems.length; s++) {
        var sEl = sidebarItems[s];
        if (sEl.getAttribute(MASKED_ATTR)) continue;
        var sTitle = sEl.querySelector("#video-title");
        var sChannel = sEl.querySelector("#channel-name");
        var sTitleText =
          sTitle && sTitle.textContent ? sTitle.textContent.trim() : "";
        var sChannelText =
          sChannel && sChannel.textContent ? sChannel.textContent.trim() : "";
        if (isProductive(sTitleText) || isProductive(sChannelText)) {
          maskElement(sEl);
        }
      }
      return;
    }

    // HOME / CHANNEL / SEARCH pages
    var selectors = [
      "ytd-rich-item-renderer",
      "ytd-video-renderer",
      "ytd-grid-video-renderer",
      "ytd-compact-video-renderer",
      "ytd-reel-item-renderer",
      "ytd-shelf-renderer",
      "ytd-playlist-renderer",
    ];
    var containers = document.querySelectorAll(selectors.join(", "));
    for (var i = 0; i < containers.length; i++) {
      var el = containers[i];
      if (el.getAttribute(MASKED_ATTR)) continue;
      var titleSelector =
        "#video-title, a#video-title, yt-formatted-string#video-title, h3 a, h3 yt-formatted-string";
      var tEl = el.querySelector(titleSelector);
      var title = tEl && tEl.textContent ? tEl.textContent.trim() : "";
      var chEl = el.querySelector(
        "ytd-channel-name yt-formatted-string, #channel-name a, #channel-name yt-formatted-string",
      );
      var channel = chEl && chEl.textContent ? chEl.textContent.trim() : "";
      if (isProductive(title) || isProductive(channel)) {
        maskElement(el);
      }
    }
  }

  // ─── Twitter/X scanning ───
  function scanTwitter() {
    var tweets = document.querySelectorAll('article[data-testid="tweet"]');
    for (var i = 0; i < tweets.length; i++) {
      var el = tweets[i];
      if (el.getAttribute(MASKED_ATTR)) continue;

      var tweetTextEl = el.querySelector('[data-testid="tweetText"]');
      var tweetText =
        tweetTextEl && tweetTextEl.textContent
          ? tweetTextEl.textContent.trim()
          : "";

      var userNameEl = el.querySelector('[data-testid="User-Name"]');
      var userName =
        userNameEl && userNameEl.textContent
          ? userNameEl.textContent.trim()
          : "";

      var cardEl = el.querySelector('[data-testid="card.wrapper"]');
      var cardText =
        cardEl && cardEl.textContent ? cardEl.textContent.trim() : "";

      var fullText = tweetText + " " + userName + " " + cardText;

      if (isProductive(fullText)) {
        maskElement(el);
        continue;
      }

      // Check known productive handles
      var handleLower = userName.toLowerCase();
      for (var h = 0; h < PRODUCTIVE_TWITTER_HANDLES.length; h++) {
        if (handleLower.indexOf("@" + PRODUCTIVE_TWITTER_HANDLES[h]) !== -1) {
          maskElement(el);
          break;
        }
      }
    }
  }

  // ─── Generic scanning ───
  function scanGeneric() {
    var items = document.querySelectorAll(
      "article, section, .card, .post, [role='article'], li",
    );
    for (var i = 0; i < items.length; i++) {
      var el = items[i];
      if (el.getAttribute(MASKED_ATTR)) continue;
      var text = (el.innerText || "").slice(0, 2000);
      if (isProductive(text)) {
        maskElement(el);
      }
    }
  }

  // ─── Main scan ───
  function scanAll() {
    var host = window.location.hostname;
    // Productive domain check
    for (var i = 0; i < PRODUCTIVE_DOMAINS.length; i++) {
      if (host.indexOf(PRODUCTIVE_DOMAINS[i]) !== -1) {
        showDomainOverlay();
        return;
      }
    }

    if (host.indexOf("youtube.com") !== -1) {
      scanYouTube();
    } else if (
      host.indexOf("x.com") !== -1 ||
      host.indexOf("twitter.com") !== -1
    ) {
      scanTwitter();
    } else if (host.indexOf("reddit.com") !== -1) {
      // Reddit: scan posts
      scanGeneric();
    } else {
      scanGeneric();
    }
  }

  // ─── Run scan ───
  // No need to check settings here - the background only injects when mode is ON
  scanAll();

  // Periodic re-scan for SPAs
  var scanTimer = setInterval(scanAll, SCAN_INTERVAL);

  // YouTube SPA navigation
  if (window.location.hostname.indexOf("youtube.com") !== -1) {
    document.addEventListener("yt-navigate-finish", function () {
      // Reset masks on navigation (new page content)
      document.querySelectorAll("[" + MASKED_ATTR + "]").forEach(function (el) {
        el.removeAttribute(MASKED_ATTR);
        el.style.removeProperty("filter");
        el.style.removeProperty("pointer-events");
        el.style.removeProperty("user-select");
        el.style.removeProperty("overflow");
        var ov = el.querySelector("." + OVERLAY_CLASS);
        if (ov) ov.remove();
      });
      setTimeout(scanAll, 300);
      setTimeout(scanAll, 1000);
      setTimeout(scanAll, 2500);
    });
  }

  // Store cleanup function
  window.__unproductive_cleanup = function () {
    clearInterval(scanTimer);
  };

  console.log(
    "[Unproductive Mode] ✅ Scanning started on",
    window.location.hostname,
  );
})();
